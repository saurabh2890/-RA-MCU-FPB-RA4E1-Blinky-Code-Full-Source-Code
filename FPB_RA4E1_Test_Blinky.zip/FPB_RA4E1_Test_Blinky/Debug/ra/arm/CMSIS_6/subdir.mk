################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CREF += \
FPB_RA4E1_Test_Blinky.cref 

MAP += \
FPB_RA4E1_Test_Blinky.map 


# Each subdirectory must supply rules for building sources it contributes

